Written by Jack Foley, C00274246

To run, execute python3 gui.py
Do not run swimming_utils.py or utils.py